	//Name______________________________ Date_____________
   import javax.swing.*;
   import java.awt.*;
    public class Odometer extends JPanel
   {
     /****************************/
     /*                          */
     /* Declare 3 fields.        */
     /*
     /* Declare 1 int variable.  */
     /*                          */
     /****************************/
   
       public Odometer()
      {
         	/*******************************/
         	/* This is the constructor.    */
         	/* Set the layout.				 */
				/* Set the background.         */
         	/* Instantiate all objects and */
      		/* set their properties.       */
      		/*	                            */ 
         	/*******************************/
      }
       public void update()
      {
         	/***************************/
         	/*                         */
         	/* Increment the counter,  */
         	/* set the labels.         */
      		/*                         */          
         	/***************************/
      }
   }