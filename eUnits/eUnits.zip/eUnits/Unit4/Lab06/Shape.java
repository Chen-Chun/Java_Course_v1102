	//Torbert, e-mail: mr@torbert.com, website: www.mr.torbert.com
	//version 4.4.2003

    public abstract class Shape
   {
       public abstract double findArea();
   }