   //Name:                 Date:
   import java.util.Scanner
    public class Driver02
   {
      public static final int NUMITEMS = 10;
       public static void main(String[] args)
      {
         //prompt the user and read the data
              
         
         
         //process the data
         
         
         
         //display the results
         
         
         
        
      }
   }