 //Name:    Date:

import java.io.*;
import java.util.*;
public class Driver01ext
{
   public static void main(String[] args) throws Exception
   {
   	//input
      Scanner infile = new Scanner( new File(   ) );
      
            
   	//sort
      
      
            
   	//output
      PrintWriter toFile = new PrintWriter(new FileWriter("output.txt"));
    
    
   }
}