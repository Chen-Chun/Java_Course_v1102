  //Name______________________________ Date_____________
  
   import java.io.*;       		 //the File class
   import java.util.*;     		 //the Scanner class
   import javax.swing.JOptionPane;
    public class Driver10
   {
       public static void main(String[] args) 
      {
         Song[] songList = input();
         int totalTime = calcTime(songList);
         int longestSong = searchLongestSong(songList);
         display(songList, totalTime, longestSong);
         System.exit(0);
      }
   	
       public static Song[] input() 
      {
          	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
      }
   
       public static int calcTime(Song[] songs)
      {
         	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
      }
      
       public static int searchLongestSong(Comparable[] songs)
      {
           	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
      }
      
       public static void display(Song[] array, int total, int longestSong)
      {
            /************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
      }
   }