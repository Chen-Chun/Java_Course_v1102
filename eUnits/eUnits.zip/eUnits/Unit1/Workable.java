	//Torbert, e-mail: mr@torbert.com, website: www.mr.torbert.com
	//version 4.16.2003

   public interface Workable
   {
      public abstract void workCorner();
      public abstract void moveOneBlock();
      public abstract void turnToTheRight();
      public abstract void turnToTheNorth();
   }